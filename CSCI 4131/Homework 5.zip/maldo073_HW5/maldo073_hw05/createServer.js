
const http = require('http');
const url = require('url');
const fs = require('fs');
const qs = require('querystring');
const jfile = require('./calendar.json');

http.createServer(function (req, res) {
    var q = url.parse(req.url, true);
    var filename = "." + q.pathname;
    //console.log(jfile.calendar[0].eventName);

    if(req.url === '/'){
        indexPage(req,res);
    } else if(req.url === '/addCalendar.html') {
        addCalendarPage(req,res);
    } else if(req.url === '/calendar.html') {
        calendarPage(req,res);
    } else if(req.url === '/index.html') {
        indexPage(req,res);
    } else if(req.url === '/calendar.json') {
        getJSON(res);
    } else if(req.url === '/postCalendarEntry') {
        formToJSON(req);
        calendarPage(req,res);
    } else {
        res.writeHead(404, {'Content-Type': 'text/html'});
        return res.end("404 Not Found");
    }
}).listen(9000);

function formToJSON(req) {
    // Get form inputs
    let body = '';
    req.on('data', chunk => {
      body += chunk.toString();
    });

    // Add to JSON file
    fs.readFile('calendar.json', 'utf8', function readFileCallback(err, data) {
      if(err) {
        throw err;
      }

      var jobj = JSON.parse(data);
      jobj.calendar.push(qs.parse(body));
      var json = JSON.stringify(jobj);
      fs.writeFile('calendar.json', json, 'utf8');
    });
}

function addCalendarPage(req, res) {
    fs.readFile('client/addCalendar.html', function(err, html) {
        if(err) {
            throw err;
        }

        res.statusCode = 200;
        res.setHeader('Content-type', 'text/html');
        res.write(html);
        res.end();
    });
}

function calendarPage(req, res) {
    fs.readFile('client/calendar.html', function(err, html) {
        if(err) {
            throw err;
        }

        res.statusCode = 200;
        res.setHeader('Content-type', 'text/html');
        res.write(html);
        res.end();
    });
}

function getJSON(res) {
    var contents = fs.readFileSync("calendar.json");
    var jcontent = JSON.parse(contents);
    
    res.statusCode = 200;
    res.setHeader('Content-type', 'application/json');
    res.write(contents);
    res.end();
}

function indexPage(req, res) {
    fs.readFile('client/index.html', function(err, html) {
        if(err) {
            throw err;
        }

        res.statusCode = 200;
        res.setHeader('Content-type', 'text/html');
        res.write(html);
        res.end();
    });
}
