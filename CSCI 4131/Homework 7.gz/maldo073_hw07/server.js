// include the express module
var express = require("express");

// create an express application
var app = express();

// helps in extracting the body portion of an incoming request stream
var bodyparser = require('body-parser');

// fs module - provides an API for interacting with the file system
var fs = require("fs");

// helps in managing user sessions
var session = require('express-session');

// used for current user session
var sess;

// native js function for hashing messages with the SHA-1 algorithm
var sha1 = require('sha1');

// include the mysql module
var mysql = require("mysql");

// the user's login
var login;

// connection Information
var cHost;
var cUser;
var cPassword;
var cDatabase;
var cPort;

// for parsing the xml file
var parser = require('xml2js');
fs.readFile( './dbconfig.xml', function(error, data) {
  if (error) {
    throw error;
  } else {

    parser.parseString(data, function (err, result) {
      cHost = result['dbconfig']['host'][0];
      cUser = result['dbconfig']['user'][0];
      cPassword = result['dbconfig']['password'][0];
      cDatabase = result['dbconfig']['database'][0];
      cPort = result['dbconfig']['port'][0];
    })
  }
 });

// apply the body-parser middleware to all incoming requests
app.use(bodyparser());

// use express-session
// in memory session is sufficient for this assignment
app.use(session({
  secret: "csci4131secretkey",
  saveUninitialized: true,
  resave: false}
));

// server listens on port 9007 for incoming connections
app.listen(9007, () => console.log('Listening on port 9007!'));

app.get('/',function(req, res) {
	res.sendFile(__dirname + '/client/welcome.html');
});

// GET method route for the login page.
// It serves login.html present in client folder
app.get('/getUser',function(req, res) {
  // if user clicks home and never logged out, they will go directly to Events page
  sess = req.session;
  if (sess.user) {
    res.send(user);
  } else {
    res.sendFile(__dirname + '/client/login.html');
  }
});

// GET method route for the login page.
// It serves login.html present in client folder
app.get('/login',function(req, res) {
  // if user clicks home and never logged out, they will go directly to Events page
  sess = req.session;
  if (sess.user) {
    res.redirect('/events');
  } else {
    res.sendFile(__dirname + '/client/login.html');
  }
});

// POST method to validate user login
// upon successful login, user session is created
app.post('/sendLoginDetails', function(req, res) {
  user = req.body.user;
  var pass = req.body.pass;

  var con = mysql.createConnection({
    host: cHost,
    user: cUser,
    password: cPassword,
    database: cDatabase,
    port:cPort
  })

  con.connect(function(err) {
    if (err) {
      throw err;
    };

    console.log("Connected to tbl_accounts!");

    var sql = 'SELECT * FROM tbl_accounts WHERE acc_login=? AND acc_password=?';

    con.query(sql, [user, sha1(pass)], function(err, result) {
      if(err) {
        throw err;
      }

      if (result.length > 0) {
        sess = req.session;
        sess.user = req.body.user;
        res.send("success");
      } else {
        res.send("fail");
      }
    });
  });
});

// // GET method route for the events page.
// It serves events.html present in client folder
app.get('/events',function(req, res) {
  sess = req.session;
  if (sess.user) {
    res.sendFile(__dirname + '/client/events.html', {user:user});
  } else {
    res.redirect('/login');
  }
});

// GET method to return the list of events
// The function queries the table events for the list of places and sends the response back to client
app.get('/getListOfEvents', function(req, res) {
  var con = mysql.createConnection({
    host: cHost,
    user: cUser,
    password: cPassword,
    database: cDatabase,
    port:cPort
  })

  con.connect(function(err) {
    if (err) {
      throw err;
    };

    console.log("Connected to tbl_events!");

    var sql = 'SELECT * FROM tbl_events';

    con.query(sql, function(err, result) {
      if(err) {
        throw err;
      }

      res.send(result);
    });
  });
});

// GET method route for the addEvents page.
// It serves addEvents.html present in client folder
app.get('/addEvents',function(req, res) {
  sess = req.session;
  if (sess.user) {
    res.sendFile(__dirname + '/client/addEvents.html');
  } else {
    res.redirect('/login');
  }
});

// POST method to insert details of a new event to tbl_events table
app.post('/postEvent', function(req, res) {
  var name = req.body.name;
  var loc = req.body.loc;
  var date = req.body.date;

  var con = mysql.createConnection({
    host: cHost,
    user: cUser,
    password: cPassword,
    database: cDatabase,
    port:cPort
  })

  con.connect(function(err) {
    if (err) {
      throw err;
    };

    console.log("Connected to tbl_events, ready to insert!");

    var sql = "INSERT INTO tbl_events (event_name, event_location, event_date) VALUES (?, ?, ?)";
    con.query(sql, [name, loc, date], function(err, result) {
      if(err) {
        throw err;
      }
      console.log("Value inserted");
      res.redirect('/events');
    });
  });
});

// GET method route for the admin page.
// It serves admin.html present in client folder
app.get('/admin',function(req, res) {
  sess = req.session;
  if (sess.user) {
    res.sendFile(__dirname + '/client/admin.html');
  } else {
    res.redirect('/login');
  }
});

// GET method to return the list of users
// The function queries the table accounts for the list of users and sends the response back to client
app.get('/getListOfUsers', function(req, res) {
  var con = mysql.createConnection({
    host: cHost,
    user: cUser,
    password: cPassword,
    database: cDatabase,
    port:cPort
  })

  con.connect(function(err) {
    if (err) {
      throw err;
    };

    console.log("Connected to tbl_accounts!");

    var sql = 'SELECT acc_id, acc_name, acc_login FROM tbl_accounts';

    con.query(sql, function(err, result) {
      if(err) {
        throw err;
      }

      res.send(result);
    });
  });
});

// POST method to insert a new user into the tbl_accounts table
app.post('/addUser', function(req, res) {
  var rows = req.body.rows;
  var name = req.body.name;
  var login = req.body.login;
  var pass = req.body.pass;

  var con = mysql.createConnection({
    host: cHost,
    user: cUser,
    password: cPassword,
    database: cDatabase,
    port:cPort
  })

  con.connect(function(err) {
      if (err) {
        throw err;
      };

    console.log("Connected to tbl_accounts ready to insert!");

    // Make sure no other user has this login
    var check = "SELECT 1 FROM tbl_accounts WHERE acc_login=?"
    con.query(check, [login], function(err, result) {
      if(err) {
        throw err;
      }

      // No user has this login, insert new user into tbl_accounts
      if (result.length == 0) {
        var sql = "INSERT INTO tbl_accounts (acc_name, acc_login, acc_password) VALUES (?, ?, ?)";
        con.query(sql, [name, login, sha1(pass)], function(err, result) {
          if(err) {
            throw err;
          }

          console.log("Value inserted");
          res.send("success");
        });
      } else {
        res.send("fail");
      }
    });
  });
});

// POST method to edit a user from the tbl_accounts table
app.post('/editUser', function(req, res) {
  var name = req.body.name;
  var login = req.body.login;
  var pass = req.body.pass;
  var oldLogin = req.body.oldLogin;

  var con = mysql.createConnection({
    host: cHost,
    user: cUser,
    password: cPassword,
    database: cDatabase,
    port:cPort
  })

  con.connect(function(err) {
      if (err) {
        throw err;
      };

    console.log("Connected to tbl_accounts ready to edit!");

    // Make sure no other user has this login
    var check = "SELECT 1 FROM tbl_accounts WHERE acc_login=?"
    con.query(check, [login], function(err, result) {
      if(err) {
        throw err;
      }

      // If user is not changing their login, just their name or password
      if (login == oldLogin) {
        result = [];
      }

      // No user has this login, edit the specified user's information
      if (result.length == 0) {
        var sql = "UPDATE tbl_accounts SET acc_name=?, acc_login=?, acc_password=? WHERE acc_login=?";
        con.query(sql, [name, login, sha1(pass), oldLogin], function(err, result) {
          if(err) {
            throw err;
          }

          console.log("Information edited");
          res.send("success");
        });
      } else {
        res.send("fail");
      }
    });
  });
});

// POST method to delete a user from the tbl_accounts table
app.post('/deleteUser', function(req, res) {
  var login = req.body.login;

  var con = mysql.createConnection({
    host: "cse-curly.cse.umn.edu",
    user: "C4131F18G51",
    password: "2651",
    database: "C4131F18G51",
    port: 3306
  })

  con.connect(function(err) {
      if (err) {
        throw err;
      };

    console.log("Connected to tbl_accounts ready to delete!");

    if (login === user) {
      res.send("fail");
    } else {
      var sql = "DELETE FROM tbl_accounts WHERE acc_login=?";
      con.query(sql, [login], function(err, result) {
        if(err) {
          throw err;
        }

        res.send("success");
      });
    }
  });
});

// log out of the application
// destroy user session
app.get('/logout', function(req, res) {
  req.session.destroy(function(err) {
    if(err) {
      console.log(err);
    } else {
      res.redirect('/login');
    }
  });
});

// middle ware to serve static files
app.use('/client', express.static(__dirname + '/client'));


// function to return the 404 message and error to client
app.get('*', function(req, res) {
  res.send('404 ERROR');
});
