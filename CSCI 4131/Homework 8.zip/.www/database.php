<!DOCTYPE html>
<html>
<body>

<?php
$xml=simplexml_load_file("dbconfig.xml") or die("Error: Cannot create object");

$db_servername = $xml->host;
$db_username = $xml->user;
$db_password = $xml->password;
$db_name = $xml->database;
$db_port = (int)$xml->port;

/*
echo $db_servername . "<br>";
echo $db_username . "<br>";
echo $db_password . "<br>";
echo $db_name . "<br>";
echo $db_port . "<br>";*/
?>

</body>
</html>
