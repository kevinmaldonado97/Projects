<?php
   session_start();
   unset($_SESSION['user']);
   unset($_SESSION['loggedin']);
   session_destroy();

   header("location: http://www-users.cselabs.umn.edu/~maldo073/login.php");
?>
