<?php
  session_start();
  include_once 'database.php';

  /*
  // if user did not log out, direct them to the events page
  if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
    header("location: http://www-users.cselabs.umn.edu/~maldo073/events.php");
  }*/

  // Create connection
  $conn=new mysqli($db_servername,$db_username,$db_password,$db_name,$db_port);

  if ( $conn->connect_error ) {
    die("Connection failed: " . $conn->connect_error);
  } else {
    if($_SERVER["REQUEST_METHOD"] == "POST") {
        $user = $_POST['user'];
        $pass = sha1($_POST['pass']);

        $query = "SELECT * FROM tbl_accounts WHERE acc_login='$user' AND acc_password='$pass'";
        $result = $conn->query($query);
        //$count = mysql_num_rows($result);
        echo($result->num_rows);

        // If result matched $user and $pass, table row must be 1 row
        if($result->num_rows > 0) {
           $_SESSION['loggedin'] = true;
           $_SESSION['user'] = $user;

           header("location: http://www-users.cselabs.umn.edu/~maldo073/events.php");
           die();
        } else {
           $error = "Your Login Name or Password is invalid";
        }
    }
  }
?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

    <title>Login Page</title>
  </head>

  <body>
   		<div class="jumbotron" style="background: DarkSeaGreen !important">
        <h1>Login Page</h1>
        <p>Please enter your user name and password. Both are case sensitive.</p>
      </div>

      <form action = "login.php" method = "post">
        <div class="userinfo">
          <label for="user"><b>User:</b></label>
          <input type="text" name="user" placeholder="Enter username" required>

          <label for="pass"><b>Password:</b></label>
          <input type="password" name="pass" placeholder="Enter password" required>

          <button id= "submit" type="Submit">Submit</button>
        </div>
      </form>

      <div style = "font-size:11px; color:#cc0000; margin-top:10px"><?php echo $error; ?></div>
  </body>
</html>
