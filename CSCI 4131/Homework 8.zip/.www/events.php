<?php
  session_start();

  if (!isset($_SESSION['loggedin']) && !$_SESSION['loggedin'] == true) {
    header("location: http://www-users.cselabs.umn.edu/~maldo073/login.php");
  }
?>

<!doctype html>
<html lang="en">
  <head>
      <meta charset="utf-8">

      <meta name="viewport" content="width=device-width, initial-scale=1">

      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
      <link rel="stylesheet" type="text/css" href="http://www-users.cselabs.umn.edu/~maldo073/style.css">

      <title>Events Page</title>

      <style type = "text/css">
         body  { font-family: sans-serif; }
         table { background-color: lightblue;
                 border-collapse: collapse;
                 border: 1px solid gray; }
         th    { padding: 5px;
                 border: 1px solid gray;}
         td    { padding: 5px;
                 border: 1px solid gray;}
         tr:nth-child(odd) {
                 background-color: white; }
         nav { background-color: yellow; }
      </style>
  </head>

  <body>
    <nav class="navbar navbar-defauid="loc"lt">
      <div class="container-fluid">
        <ul class="nav navbar-nav">
          <li><a href="http://www-users.cselabs.umn.edu/~maldo073/events.php"><b>Events Page</b></a></li>
          <li><a href="http://www-users.cselabs.umn.edu/~maldo073/logout.php"><span class="glyphicon glyphicon-log-out"></span></a></li>
        </ul>
      </div>
    </nav>

    <form action="events.php" method="post">
      <input type="radio" name="order" value="eName" checked="checked"> Event Name<br>
      <input type="radio" name="order" value="eLocation"> Event Location<br>
      <input type="radio" name="order" value="eDate"> Event Date<br>
    </form>

    <?php
       include_once 'database.php';

       // Create connection
       $conn=new mysqli($db_servername,$db_username,$db_password,$db_name,$db_port);

       if ( $conn->connect_error ) {
         die("Connection failed: " . $conn->connect_error);
       } else {
         $query = "SELECT event_name, event_location, event_date FROM tbl_events";
         $result = $conn->query($query);
       }
    ?>

    <table>
         <?php
            print("<tr><th>Event Name</th><th>Location</th><th>Date</th></tr>");
            $count = 0;
            $order = $_POST['order'];

            /*
            if ($order == "eName") {
                echo 'eName';
            }
            else if ($order == "eLocation") {
                echo 'eLocation';
            } else {
                echo 'eDate';
            }*/

            // fetch each record in result set
            while ( $row = mysqli_fetch_row( $result ) ) {
               // build table to display results
               print( "<tr>" );

               foreach ( $row as $value )
                  print( "<td>$value</td>" );
                  $count++;

               print( "</tr>" );
            } // end while
            //print($count);
            $conn->close();
         ?>
    </table>
  </body>
</html>
